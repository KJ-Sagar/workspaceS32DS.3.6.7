/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           :
*   Dependencies         : none
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 7.0.1
*   Build Version        : S32K3_RTD_7_0_1_D2602_ASR_REL_4_9_REV_0000_20260206
*
*   Copyright 2020 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file    SchM_BaseNXP.h
*   @version 7.0.1
*
*   @brief   AUTOSAR Rte - module interface
*   @details This file contains the functions prototypes and data types of the AUTOSAR Rte.
*            This file contains sample code only. It is not part of the production code deliverables.
*
*   @addtogroup RTE_MODULE
*   @{
*/

#ifndef SCHM_BASENXP_H
#define SCHM_BASENXP_H

#ifdef __cplusplus
extern "C" {
#endif
/*==================================================================================================
*                                         INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

/*==================================================================================================
*                               SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define SCHM_BASENXP_AR_RELEASE_MAJOR_VERSION     4
#define SCHM_BASENXP_AR_RELEASE_MINOR_VERSION     9
#define SCHM_BASENXP_AR_RELEASE_REVISION_VERSION  0
#define SCHM_BASENXP_SW_MAJOR_VERSION             7
#define SCHM_BASENXP_SW_MINOR_VERSION             0
#define SCHM_BASENXP_SW_PATCH_VERSION             1

/*==================================================================================================
*                                      FILE VERSION CHECKS
==================================================================================================*/


/*==================================================================================================
*                                           CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/
#ifdef RTE_NUMBER_OF_CORES
#define NUMBER_OF_CORES         (RTE_NUMBER_OF_CORES)
#else
#define NUMBER_OF_CORES         (uint8)(4U)
#endif

/*==================================================================================================
*                                             ENUMS
==================================================================================================*/

/*==================================================================================================
*                                 STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                 GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                     FUNCTION PROTOTYPES
==================================================================================================*/
#define RTE_START_SEC_CODE
#include "Rte_MemMap.h"

#ifdef MCAL_TESTING_ENVIRONMENT
/**
@brief   This function checks that all entered exclusive areas were also exited.
@details This function checks that all entered exclusive areas were also exited. The check
         is done by verifying that all reentry_guard_* static variables are back to the
         zero value.

@param[in]     void       No input parameters
@return        void       This function does not return a value. Test asserts are used instead.

@pre  None
@post None

@remarks Covers
@remarks Implements
*/
void SchM_Check_basenxp(void);
#endif /*MCAL_TESTING_ENVIRONMENT*/

extern void SchM_Enter_BaseNXP_BASENXP_EXCLUSIVE_AREA_00(void);
extern void SchM_Exit_BaseNXP_BASENXP_EXCLUSIVE_AREA_00(void);

extern void SchM_Enter_BaseNXP_BASENXP_EXCLUSIVE_AREA_01(void);
extern void SchM_Exit_BaseNXP_BASENXP_EXCLUSIVE_AREA_01(void);

#define RTE_STOP_SEC_CODE
#include "Rte_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* SCHM_BASENXP_H */
