/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           :
*   Dependencies         : none
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 7.0.1
*   Build Version        : S32K3_RTD_7_0_1_D2602_ASR_REL_4_9_REV_0000_20260206
*
*   Copyright 2020 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CLOCK_IP_DERIVATIVE_010_H
#define CLOCK_IP_DERIVATIVE_010_H

/**
*   @file       Clock_Ip_Derivative_010.h
*   @version    7.0.1
*
*   @brief   AUTOSAR Mcu - Post-Build(PB) configuration file code template.
*   @details Code template for Post-Build(PB) configuration file generation.
*
*   @addtogroup CLOCK_DRIVER Clock Ip Driver
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif


/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

/*==================================================================================================
                               SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define CLOCK_IP_DERIVATIVE_010_VENDOR_ID                       43
#define CLOCK_IP_DERIVATIVE_010_AR_RELEASE_MAJOR_VERSION        4
#define CLOCK_IP_DERIVATIVE_010_AR_RELEASE_MINOR_VERSION        9
#define CLOCK_IP_DERIVATIVE_010_AR_RELEASE_REVISION_VERSION     0
#define CLOCK_IP_DERIVATIVE_010_SW_MAJOR_VERSION                7
#define CLOCK_IP_DERIVATIVE_010_SW_MINOR_VERSION                0
#define CLOCK_IP_DERIVATIVE_010_SW_PATCH_VERSION                1

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/

/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/


#define CLOCK_IP_DIVIDER_CALLBACKS_COUNT                                               5U
#define CLOCK_IP_CGM_X_DE_DIV_STAT_WITHOUT_PHASE                                       1U
#define CLOCK_IP_CGM_X_DE_DIV_STAT_WITHOUT_PHASE_WAIT_FOR_HSE_CORE                     2U
#define CLOCK_IP_PLL_PLL0DIV_DE_DIV_OUTPUT                                             3U
#define CLOCK_IP_PLL_PLLDV_ODIV2_OUTPUT                                                4U

#define CLOCK_IP_DIVIDERTRIGGER_CALLBACKS_COUNT                                        2U
#define CLOCK_IP_CGM_X_DIV_TRIG_CTRL_TCTL_HHEN_UPD_STAT                                1U

#define CLOCK_IP_XOSC_CALLBACKS_COUNT                                                  3U
#define CLOCK_IP_FXOSC_OSCON_BYP_EOCV_GM_SEL                                           1U
#define CLOCK_IP_SXOSC_OSCON_EOCV_CURR_PRG_SF_CURR_PRG_COMP_GM_SEL                     2U

#define CLOCK_IP_IRCOSC_CALLBACKS_COUNT                                                4U
#define CLOCK_IP_FIRC_STDBY_ENABLE                                                     1U
#define CLOCK_IP_SIRC_STDBY_ENABLE                                                     2U
#define CLOCK_IP_FIRC_DIV_SEL_HSEb_CONFIG_REG_GPR                                      3U

#define CLOCK_IP_GATE_CALLBACKS_COUNT                                                  2U
#define CLOCK_IP_MC_ME_PARTITION_COFB_ENABLE_REQUEST                                   1U

#define CLOCK_IP_FRACTIONAL_DIVIDER_CALLBACKS_COUNT                                     1U

#define CLOCK_IP_PLL_CALLBACKS_COUNT                                                   3U
#define CLOCK_IP_PLL_RDIV_MFI_MFN_ODIV2_SDMEN_SSCGBYP_SPREADCTL_STEPNO_STEPSIZE        1U
#define CLOCK_IP_PLL_RDIV_MFI_MFN_ODIV2_SDMEN                                          2U

#define CLOCK_IP_SELECTOR_CALLBACKS_COUNT                                              5U
#define CLOCK_IP_CGM_X_CSC_CSS_CLK_SW_SWIP                                             1U
#define CLOCK_IP_CGM_X_CSC_CSS_CLK_SW_RAMPDOWN_RAMPUP_SWIP                             2U
#define CLOCK_IP_CGM_X_CSC_CSS_CS_GRIP                                                 3U
#define CLOCK_IP_RTC_RTCC_CLKSELECT                                                    4U

#define CLOCK_IP_PCFS_CALLBACKS_COUNT                                                  2U
#define CLOCK_IP_CGM_X_PCFS_SDUR_DIVC_DIVE_DIVS                                        1U

#define CLOCK_IP_CMU_CALLBACKS_COUNT                                                   2U
#define CLOCK_IP_CMU_FC_FCE_REF_CNT_LFREF_HFREF                                        1U

#define CLOCK_IP_CMU_INSTANCES_NO                                                      5U

#define CLOCK_IP_QSPI_SFCK_CLK_DIV2_SUPPORTED
#define CLOCK_IP_GMAC0_TX_CLK_DIV2_SUPPORTED
#define CLOCK_IP_GMAC1_TX_CLK_DIV2_SUPPORTED
#define CLOCK_IP_TRACE_CLK_DIV2_SUPPORTED

#define CLOCK_IP_FLASH_WAIT_STATES_THRESHOLD1 60000000U
#define CLOCK_IP_FLASH_WAIT_STATES_THRESHOLD2 90000000U
#define CLOCK_IP_FLASH_WAIT_STATES_THRESHOLD3 120000000U
#define CLOCK_IP_FLASH_WAIT_STATES_THRESHOLD4 150000000U
#define CLOCK_IP_FLASH_WAIT_STATES_THRESHOLD5 180000000U
#define CLOCK_IP_FLASH_WAIT_STATES_THRESHOLD6 210000000U
#define CLOCK_IP_FLASH_WAIT_STATES_THRESHOLD7 240000000U
#define CLOCK_IP_FLASH_WAIT_STATES_THRESHOLD8 250000000U

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/



#ifdef __cplusplus
}
#endif

/** @} */
#endif /* #ifndef CLOCK_IP_DERIVATIVE_010_H */

