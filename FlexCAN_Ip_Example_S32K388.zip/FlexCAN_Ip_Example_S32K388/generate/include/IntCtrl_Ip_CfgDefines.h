/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : none
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 7.0.1
*   Build Version        : S32K3_RTD_7_0_1_D2602_ASR_REL_4_9_REV_0000_20260206
*
*   Copyright 2020 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be 
*   used strictly in accordance with the applicable license terms. By expressly 
*   accepting such terms or by downloading, installing, activating and/or otherwise 
*   using the software, you are agreeing that you have read, and that you agree to 
*   comply with and are bound by, such license terms. If you do not agree to be 
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef INTCTRL_IP_CFG_DEFINES_H_
#define INTCTRL_IP_CFG_DEFINES_H_

#ifdef __cplusplus
extern "C"{
#endif
/*==================================================================================================
                                         INCLUDE FILES
==================================================================================================*/
#include "Std_Types.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define CDD_PLATFORM_INTCTRL_IP_CFG_DEFINES_VENDOR_ID                          43
#define CDD_PLATFORM_INTCTRL_IP_CFG_DEFINES_SW_MAJOR_VERSION                   7
#define CDD_PLATFORM_INTCTRL_IP_CFG_DEFINES_SW_MINOR_VERSION                   0
#define CDD_PLATFORM_INTCTRL_IP_CFG_DEFINES_SW_PATCH_VERSION                   1
#define CDD_PLATFORM_INTCTRL_IP_CFG_DEFINES_AR_RELEASE_MAJOR_VERSION           4
#define CDD_PLATFORM_INTCTRL_IP_CFG_DEFINES_AR_RELEASE_MINOR_VERSION           9
#define CDD_PLATFORM_INTCTRL_IP_CFG_DEFINES_AR_RELEASE_REVISION_VERSION        0
/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/
/**
* @brief Interrupt Controller feature enablement.
*/
#define PLATFORM_IP_ENABLE_INT_CTRL (STD_ON)
/* CPU to CPU interrupt (MSI) routing through MSCM */
#define INT_CTRL_IP_MSI_AVAILABLE   (STD_OFF)

#if (INT_CTRL_IP_MSI_AVAILABLE == STD_ON)
    /* MSI target core count */
    #define INT_CTRL_IP_MSI_CORE_CNT                   (4U)
    /* MSI vector min */
    #define INT_CTRL_IP_DIRECTED_CPU_INT_MIN           (INT0_IRQn)
    /* MSI vector max */
    #define INT_CTRL_IP_DIRECTED_CPU_INT_MAX           (INT3_IRQn)
#endif
#include "S32K388_NVIC.h"
#include "S32K388_MSCM.h"
#include "S32K388_SCB.h"
#if (INT_CTRL_IP_MSI_AVAILABLE == STD_ON)
    typedef struct {
        __IO uint32_t IntStatusR;  /**< Interrupt Router CPn Interruptx Status Register; array offset: 0x200; index*0x20; index2*0x8 */
        __O  uint32_t IGR;  /**< Interrupt Router CPn Interruptx Generation Register; array offset: 0x204; index*0x20; index2*0x8 */
    } MSCM_IRCP_IR_Type;

    typedef struct {
        MSCM_IRCP_IR_Type IRCPnIRx[4][4];
    } MSCM_IRCPnIRx_Type;

    #define MSCM_IRCPnIRx ((volatile MSCM_IRCPnIRx_Type*)&IP_MSCM->IRCP0ISR0)
#endif
        
/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/
/* Development error detection */
/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/
#define INT_CTRL_IP_DEV_ERROR_DETECT              (STD_ON)
/* VTOR address configuration enable */
#define INT_CTRL_IP_ENABLE_VTOR_CONFIG            (STD_OFF)
/* IP standalone APIs  */
#define INT_CTRL_IP_STANDALONE_APIS               (STD_ON)
/* First implemented interrupt vector */
#define INT_CTRL_IP_MIN_IRQ                       (INT0_IRQn)
/* Last implemented interrupt vector */
#define INT_CTRL_IP_MAX_IRQ                       (GMAC1_SIUC_IRQn)
/* The interrupt counter value*/
#define INT_CTRL_IP_IRQ_COUNT                     (210U)
/* Arm Cortex M */
#define INT_CTRL_IP_CORTEXM                       (STD_ON)
/* Arm Cortex M0+ */
#define INT_CTRL_IP_CORTEXM0PLUS                  (STD_OFF)
/* Arm Cortex R */
#define INT_CTRL_IP_CORTEXR                       (STD_OFF)
/* Arm Cortex A */
#define INT_CTRL_IP_CORTEXA                       (STD_OFF)

/* Number of nvic priority bits implemented */
#define INT_CTRL_IP_NVIC_PRIO_BITS                (4U)
/* This instruction invalidates the entire instruction cache or caches */
#define INT_CTRL_IP_INVALIDATE_CACHE              (STD_OFF)

/* User mode support */
#define INTCTRL_PLATFORM_ENABLE_USER_MODE_SUPPORT (STD_OFF)

#ifdef __cplusplus
}
#endif

#endif /* INTCTRL_IP_CFG_DEFINES_H_ */

